sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("iot.planner.projects.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
